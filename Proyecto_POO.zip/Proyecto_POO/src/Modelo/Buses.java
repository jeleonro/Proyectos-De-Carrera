package Modelo;
import java.util.Date;
public class Buses { 
    String placa;
    String modelo;
    int capacidad;
    private String añofabricacion;
    private String seguro;
    
    public Buses(){}
    
    public Object[] RegistroBuses(){
        Object[] filabus = {placa, modelo, capacidad, añofabricacion, seguro};
        return filabus;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public String getAñofabricacion() {
        return añofabricacion;
    }

    public void setAñofabricacion(String añofabricacion) {
        this.añofabricacion = añofabricacion;
    }

    public String getSeguro() {
        return seguro;
    }

    public void setSeguro(String seguro) {
        this.seguro = seguro;
    }

}
