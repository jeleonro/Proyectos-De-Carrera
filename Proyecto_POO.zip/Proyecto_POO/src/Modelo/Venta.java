
package Modelo;

import java.util.Date;

public class Venta {
    private String clienteregistrado;
    private String inicioviaje;
    private String destinoviaje;
    private Date fechaviaje;
    private String costopasaje;
    private String estadopago;
    private String asiento;
    public Object[] RegistroVentas() {
        Object[] filaventas ={clienteregistrado,inicioviaje,destinoviaje,
                            fechaviaje,costopasaje,asiento,estadopago};
        return filaventas;
    }

    public String getClienteregistrado() {
        return clienteregistrado;    }
    public void setClienteregistrado(String clienteregistrado) {
        this.clienteregistrado = clienteregistrado;    }
    public String getInicioviaje() {
        return inicioviaje;    }
    public void setInicioviaje(String inicioviaje) {
        this.inicioviaje = inicioviaje;    }
    public String getDestinoviaje() {
        return destinoviaje;}
    public void setDestinoviaje(String destinoviaje) {
        this.destinoviaje = destinoviaje;    }
    public Date getFechaviaje() {
        return fechaviaje;    }
    public void setFechaviaje(Date fechaviaje) {
        this.fechaviaje = fechaviaje;    }
    public String getCostopasaje() {
        return costopasaje;    }
    public void setCostopasaje(String costopasaje) {
        this.costopasaje = costopasaje;    }
    public String getEstadopago() {
        return estadopago;    }
    public void setEstadopago(String estadopago) {
        this.estadopago = estadopago;    }  

    public String getAsiento() {
        return asiento;
    }

    public void setAsiento(String asiento) {
        this.asiento = asiento;
    }
   }
