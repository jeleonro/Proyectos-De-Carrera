package Modelo;

public class Chofer {
    String nombre;
    String apellido;
    String numlicencia;
    String estadolic;
    String telefono;

    public Chofer() {
    }
    
    public Object[] RegistroChofer(){
        Object[] fila = {nombre,apellido,numlicencia,estadolic,telefono};
        return fila;
    }

    public String getNombre() {
        return nombre;    }
    public void setNombre(String nombre) {
        this.nombre = nombre;    }
    public String getApellido() {
        return apellido;    }
    public void setApellido(String apellido) {
        this.apellido = apellido;    }
    public String getNumlicencia() {
        return numlicencia;    }
    public void setNumlicencia(String numlicencia) {
        this.numlicencia = numlicencia;    }
    public String getEstadolic() {
        return estadolic;    }
    public void setEstadolic(String estadolic) {
        this.estadolic = estadolic;    }
    public String getTelefono() {
        return telefono;    }
    public void setTelefono(String telefono) {
        this.telefono = telefono;    }
}
