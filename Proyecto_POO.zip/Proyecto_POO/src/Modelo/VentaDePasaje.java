package Modelo;

import Datos.Acciones;
import Datos.Constantes;
import java.util.HashMap;

public class VentaDePasaje extends Venta implements Constantes, Acciones {

    private double pasaje;

    @Override
    public String CalcularPrecioPasaje(String origen,String destino) {
        HashMap<String, Double> preciosRuta = new HashMap<>();
        preciosRuta.put("Lima-Ica", 50.0);
        preciosRuta.put("Lima-Pisco", 55.0);
        preciosRuta.put("Lima-Ica", 50.0);
        preciosRuta.put("Lima-Paracas", 60.0);
        preciosRuta.put("Ica-Lima", 70.0);
        preciosRuta.put("Ica-Paracas", 50.0);
        preciosRuta.put("Ica-Pisco", 60.0);
        preciosRuta.put("Pisco-Ica", 80.0);
        preciosRuta.put("Pisco-Paracas", 60.0);
        preciosRuta.put("Pisco-Lima", 80.0);
        preciosRuta.put("Paracas-Ica", 90.0);
        preciosRuta.put("Paracas-Pisco", 60.0);
        preciosRuta.put("Paracas-Lima", 70.0);
        
        if (!"Seleccionar".equals(origen) && !"Seleccionar".equals(destino)) {
            String claveRuta = origen + "-" + destino;
            Double precio = preciosRuta.get(claveRuta);

            if (precio != null) {
                return "S/ " + precio;
            } else {
                return "No disponible";
            }
        }
        return ""; // Limpiar si no hay selección válida
    }
}
