package Modelo;

public class Distribuidor {

    private int idDistribuidor;

    private String nombre;

    public int getIdDistribuidor() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setIdDistribuidor(int idDistribuidor) {
    }

    public String getNombre() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public void setNombre(String nombre) {
    }
}
