package Modelo;

import java.util.Date;

public class Rutas {
    private String inicioruta;
    private String destinoruta;
    private Date fecha;
    private Date hora;
    private String busasignado;
    private String choferasignado;

    public Rutas() {
    }
    
    public Object[] ProgramarRuta(){
        Object[] filarutas = {inicioruta, destinoruta, fecha, hora, busasignado,choferasignado};
        return filarutas;
    }

    public String getInicioruta() {
        return inicioruta;    }
    public void setInicioruta(String inicioruta) {
        this.inicioruta = inicioruta;    }
    public String getDestinoruta() {
        return destinoruta;    }
    public void setDestinoruta(String destinoruta) {
        this.destinoruta = destinoruta;    }
    public Date getFecha() {
        return fecha;    }
    public void setFecha(Date fecha) {
        this.fecha = fecha;    }
    public Date getHora() {
        return hora;    }
    public void setHora(Date hora) {
        this.hora = hora;    }
    public String getBusasignado() {
        return busasignado;    }
    public void setBusasignado(String busasignado) {
        this.busasignado = busasignado;    }
    public String getChoferasignado() {
        return choferasignado;    }
    public void setChoferasignado(String choferasignado) {
        this.choferasignado = choferasignado;    }    
}
