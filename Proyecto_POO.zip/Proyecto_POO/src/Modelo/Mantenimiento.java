/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.Date;

public class Mantenimiento {
    private String bus;
    private String detalle;
    private Date fechamantenimiento;

    public String getBus() {
        return bus;
    }

    public void setBus(String bus) {
        this.bus = bus;
    }

    public String getDetalle() {
        return detalle;
    }

    public void setDetalle(String detalle) {
        this.detalle = detalle;
    }

    public Date getFechamantenimiento() {
        return fechamantenimiento;
    }

    public void setFechamantenimiento(Date fechamantenimiento) {
        this.fechamantenimiento = fechamantenimiento;
    }
    
}
