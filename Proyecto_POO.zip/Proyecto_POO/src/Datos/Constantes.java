package Datos;

public interface Constantes {
    String sexo[] = {"MASCULINO", "FEMENINO"};
    String origen[] = {"Seleccionar","Lima", "Ica", "Pisco","Paracas"};
    String destino[] = {"Seleccionar","Ica", "Pisco","Paracas","Lima"};
    String estadopasaje[] = {"Pagado","En Espera"};
    String motivo[]={"Cambio de Llanta","Cambio de Aceite","Embrague defectuoso","Fuga de aceite"+
"Batería descargada","Desgaste de las pastillas de freno","Cambio de la correa de distribución","Reparaciones menores","Reparaciones costosas"};
    String tipopasaje[] = {"Bus Cama", "Bus Normal"};
    String modelobus[]={"Marcopolo Paradiso G71200","Marcopolo Paradiso G81800",
        "Modasa Zeus 3","Modasa Apollo","King Long XMQ6130Y","Setra","Scania K410","Scania K440","Mercedes-Benz"};
    String segurobus[]={"SOAT","CAT"};
}