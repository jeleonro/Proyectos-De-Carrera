package Datos;

public interface Acciones {
    public String CalcularPrecioPasaje(String origen,String destino);
}
