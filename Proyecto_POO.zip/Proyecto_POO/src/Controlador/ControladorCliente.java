package Controlador;

import Configuracion.Conexion;
import Servicios.*;
import Dao.*;
import Vista.*;
import Modelo.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorCliente extends Conexion implements ActionListener {
    FrmRegistroCliente vista;
    DaoClientes crud;
    Cliente cl;
    public ControladorCliente(FrmRegistroCliente frc) {
        vista = frc;
        vista.setTitle("REGISTRO DE CLIENTES");
        vista.setVisible(true);
        Procesos.ProcesoCliente.Presentar(frc);
        // Asignar listeners a los botones
        vista.btnRegistroCliente.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnRegistroCliente) {
            crud = new DaoClientes(vista);
            if (crud.registrarCliente(cl)) { // Si el registro es exitoso
                limpiarCampos();  // Limpiar los campos de entrada tras el registro

            }
        }
    }

  

    private void limpiarCampos() {
        vista.jtxtNombre.setText("");
        vista.jtxtApellido.setText("");
        vista.jcbxSexo.setSelectedItem(0);
        vista.jtxaDni.setText("");
        vista.jtxtTelefono.setText("");
    }
}

