package Controlador;
//librerias
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import Vista.*;

import Principal.*;
import javax.swing.JFrame;

public class ControladorMenu implements ActionListener {
    FormularioMenu  vista;
    public ControladorMenu(FormularioMenu fm){
        vista = fm;
        vista.mitemRegistroBuses.addActionListener(this);
        vista.miitemGestionBuses.addActionListener(this);
        vista.miitemMantenimiento.addActionListener(this);
        vista.mitemRegistroChoferes.addActionListener(this);
        vista.miitemgestionchofer.addActionListener(this);
        vista.mitemRegistrodeClientes.addActionListener(this);
        vista.miitemgestioncliente.addActionListener(this);
        vista.mitemRutasViaje.addActionListener(this);
        vista.miitemDetalleventa.addActionListener(this);
        vista.miitemGestionVentaPasaje.addActionListener(this);
        vista.miVentaPasaje.addActionListener(this);
        fm.setExtendedState(JFrame.MAXIMIZED_BOTH);
        fm.setDefaultCloseOperation(fm.EXIT_ON_CLOSE);
        fm.setVisible(true);
        fm.setTitle("APLICACION DE GESTION DE VENTAS DE PASAJES");  
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
      if(e.getSource()== vista.mitemRegistroChoferes){
          Main.frc = new FrmRegistroChofer();
          Main.controlchofer = new ControladorChofer(Main.frc);          
          vista.jdpnContenedor.add(Main.frc);          
      }
      
      if(e.getSource()== vista.miitemgestionchofer){
          Main.fgc = new FrmGestionarChofer();
          Main.cgc = new ControlGestionChoferes(Main.fgc);          
          vista.jdpnContenedor.add(Main.fgc);          
      }
      
      if(e.getSource()== vista.mitemRegistroBuses){
          Main.frb = new FrmRegistroBuses();
          Main.controlbus = new ControladorBuses(Main.frb);          
          vista.jdpnContenedor.add(Main.frb);          
      }
      
      if(e.getSource()== vista.miitemGestionBuses){
          Main.fgb = new FrmGestionarBuses();
          Main.cgb = new ControlGestionBuses(Main.fgb);          
          vista.jdpnContenedor.add(Main.fgb);          
      }
      
      if(e.getSource()== vista.mitemRegistrodeClientes){
          Main.fc = new FrmRegistroCliente();
          Main.controlcliente = new ControladorCliente(Main.fc);          
          vista.jdpnContenedor.add(Main.fc);          
      }     
      
      if(e.getSource()== vista.miitemgestioncliente){
          Main.fgcli = new FrmGestionarClientes();
          Main.cgcli = new ControlGestionClientes(Main.fgcli);          
          vista.jdpnContenedor.add(Main.fgcli);          
      } 
      
      if(e.getSource()== vista.mitemRutasViaje){
          Main.frv = new FrmRutasViaje();
          Main.controlrutas= new ControladorRutas(Main.frv);          
          vista.jdpnContenedor.add(Main.frv);          
      }
      
      if(e.getSource()== vista.miVentaPasaje){
          Main.fvp = new FrmVentaPasaje();
          Main.cv= new ControladorVentas(Main.fvp);          
          vista.jdpnContenedor.add(Main.fvp);          
      }
      
      if(e.getSource()== vista.miitemGestionVentaPasaje){
          Main.fgv = new FrmGestionarVentas();
          Main.cgv= new ControlGestionVentas(Main.fgv);          
          vista.jdpnContenedor.add(Main.fgv);          
      }
      
      if(e.getSource()== vista.miitemDetalleventa){
          Main.fdv = new FrmDetalleVenta();
          Main.cdv= new ControlDetalleVenta(Main.fdv);          
          vista.jdpnContenedor.add(Main.fdv);          
      }
      
      if(e.getSource()== vista.miitemMantenimiento){
          Main.fm = new FrmMantenimiento();
          Main.cm= new ControladorMantenimiento(Main.fm);          
          vista.jdpnContenedor.add(Main.fm);          
      }
      }    
}
    