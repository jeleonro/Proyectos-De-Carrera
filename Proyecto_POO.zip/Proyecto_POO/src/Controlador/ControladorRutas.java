package Controlador;

import Configuracion.Conexion;
import Servicios.*;
import Dao.*;
import Vista.*;
import Formatos.Mensajes;
import Modelo.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorRutas extends Conexion implements ActionListener {

    FrmRutasViaje vista;
    DaoRuta crud;
    Rutas r;
    Buses b;
    Chofer c;

    public ControladorRutas(FrmRutasViaje frv) {
        vista = new FrmRutasViaje();
        vista = frv;
        vista.setTitle("PROGRAMAR RUTAS");
        vista.setVisible(true);
        Procesos.ProcesoRutas.Presentar(frv);
        // Asignar listeners a los botones
        vista.btnProgramar.addActionListener(this);
        vista.btnEliminar.addActionListener(this);
        vista.btnBuscarChofer.addActionListener(this);
        vista.btnBuscarBus.addActionListener(this);       
        actualizarTablaRuta();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        if (e.getSource() == vista.btnProgramar) {
            crud = new DaoRuta(vista);
            if (crud.ProgramarRuta(r)) { // Si el registro es exitoso
                actualizarTablaRuta();
                limpiarCampos();// Actualiza la tabla
            }
        }
        if (e.getSource() == vista.btnBuscarBus) {
            String placa = Mensajes.M2("Ingrese la placa del bus a buscar");
            crud = new DaoRuta(vista);
            b = new Buses();
            b = crud.ConsultarBus(placa);
            if (b == null) {
                Mensajes.M1("La placa : " + placa + "no existe en la tabla");
            } else {
                vista.jtxtBus.append("Placa :" + b.getPlaca()+"\n");
                vista.jtxtBus.append("Modelo :" + b.getModelo());
            }
        }
        if (e.getSource() == vista.btnBuscarChofer){
            String licencia = Mensajes.M2("Ingrese el num. de licencia del chofer a buscar");
            crud = new DaoRuta(vista);
            c = new Chofer();
            c = crud.ConsultarChofer(licencia);
            if (c == null) {
                Mensajes.M1("La licencia con numero :" + licencia + "no existe en la tabla");
            } else {
                vista.jtxtChofer.append("Chofer :" + c.getNombre()+" "+c.getApellido()+"\n");
                vista.jtxtChofer.append("Num. Licencia :" + c.getNumlicencia()+"\n");
                vista.jtxtChofer.append("Estado :" + c.getEstadolic());
            }
        }
        if (e.getSource() == vista.btnEliminar){
            crud = new DaoRuta(vista);
            int fila= vista.tblRutas.getSelectedRowCount();
            if(fila<1){
                JOptionPane.showMessageDialog(null, "SELECCIONE UN REGISTRO");
            }else{
                if(DaoGestionClientes.eliminarcliente(vista.tblRutas.getValueAt(vista.tblRutas.getSelectedRow(), 2).toString()));               
                JOptionPane.showMessageDialog(null, "RUTA ELIMINADA CORRECTAMENTE...");
                actualizarTablaRuta();
            }
        }
        
    }

    private void actualizarTablaRuta() {
        crud = new DaoRuta(vista);
        ServicioRuta.MostrarRutas(crud.ListaRuta(), vista);
    }

    private void limpiarCampos() {
        vista.jcbxOrigenruta.setSelectedItem(0);
        vista.jcbxDestino.setSelectedItem(0);
        vista.jdtf_fecha.setDate(null);
        vista.jdtf_hora.setDate(null);
        vista.jtxtBus.setText("");
        vista.jtxtChofer.setText("");
    }
}
