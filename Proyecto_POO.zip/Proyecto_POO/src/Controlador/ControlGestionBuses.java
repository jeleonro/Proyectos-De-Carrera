/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Configuracion.Conexion;
import Dao.DaoBuses;
import Dao.DaoGestionBuses;
import Dao.DaoRuta;
import Formatos.Mensajes;
import Modelo.Buses;
import Controlador.*;
import Servicios.ServicioBuses;
import Vista.FrmGestionarBuses;
import Vista.FrmRegistroBuses;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControlGestionBuses extends Conexion implements ActionListener {

    FrmGestionarBuses vista;
    FrmRegistroBuses frmb;
    DaoGestionBuses dgb;
    DaoBuses db;
    Buses b;

    public ControlGestionBuses(FrmGestionarBuses fgb) {
        vista = fgb;
        vista.btnActualizarBus.addActionListener(this);
        vista.btnEliminarBus.addActionListener(this);
        vista.setTitle("REGISTRO DE BUSES");
        vista.setVisible(true);
        actualizarTablabuses();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnActualizarBus) {
                actualizarTablabuses(); // Actualiza la tabla
        }       
        if (e.getSource() == vista.btnEliminarBus) {
            int fila= vista.tblBuses.getSelectedRowCount();
            if(fila<1){
                JOptionPane.showMessageDialog(null, "SELECCIONE UN REGISTRO");
            }else{
                if(DaoGestionBuses.eliminarbus(vista.tblBuses.getValueAt(vista.tblBuses.getSelectedRow(), 1).toString()));
                actualizarTablabuses();
                JOptionPane.showMessageDialog(null, "BUS ELIMINADO");
            }
        }
    }


    private void actualizarTablabuses(){
        dgb = new DaoGestionBuses(vista);
        ServicioBuses.MostrarBuses(dgb.ListaBuses(), vista);
    }

}
