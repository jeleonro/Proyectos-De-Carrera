/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Dao.DaoGestionClientes;
import Dao.DaoGestionVentas;
import Dao.DaoRuta;
import Formatos.Mensajes;
import Modelo.*;
import Servicios.ServicioClientes;
import Servicios.ServicioRuta;
import Servicios.ServicioVentasPasajes;
import Vista.FrmGestionarClientes;
import Vista.FrmGestionarVentas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.event.AncestorListener;

public class ControlGestionVentas implements ActionListener{

    DaoGestionVentas crud;
    FrmGestionarVentas vista;
    Cliente c;
  
    public ControlGestionVentas(FrmGestionarVentas fgv) {
        vista = fgv;
        vista.btnFiltrarfechas.addActionListener(this);
        vista.setTitle("GESTION DE VENTAS");
        vista.setVisible(true);
        crud = new DaoGestionVentas(vista);
        crud.actualizarTablaVentas();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnFiltrarfechas) {
        crud = new DaoGestionVentas(vista);
        Date fechaSeleccionada = vista.jdtFechaseleccionada.getDate();
        if (fechaSeleccionada != null) {
            ServicioVentasPasajes.MostrarVentas(crud.filtrarPorFecha(fechaSeleccionada), vista);
        } else {
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fecha válida.");
        }
    }
    }}


