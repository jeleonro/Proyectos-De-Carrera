package Controlador;

import Configuracion.Conexion;
import Dao.DaoDetalles;
import Dao.DaoRuta;
import Formatos.Mensajes;
import Servicios.*;
import Modelo.Buses;
import Modelo.Chofer;
import Modelo.Cliente;
import Modelo.Venta;
import Vista.FrmDetalleVenta;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class ControlDetalleVenta extends Conexion implements ActionListener {

    FrmDetalleVenta vista;
    DaoDetalles crud;
    Venta v;
    Cliente c;

    public ControlDetalleVenta(FrmDetalleVenta fdv) {
        vista = fdv;
        vista.setTitle("DETALLES DE VENTA");
        vista.setVisible(true);
        Procesos.ProcesoVentas.CargarClientes(vista.jcbxClientesRegistrados);;
        // Asignar listeners a los botones
        vista.btnBuscarVenta.addActionListener(this);
        vista.btnLimpiar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnBuscarVenta) {
            String cliente = vista.jcbxClientesRegistrados.getSelectedItem().toString();
            crud = new DaoDetalles(vista);
            v = new Venta();
            c = new Cliente();
            v = crud.ConsultarVenta(cliente);
            c = crud.ConsultarCliente(cliente);
            if (v == null) {
                Mensajes.M1("El pasaje del cliente :" + cliente + "no existe en la tabla");
            } else {
                vista.jTextArea1.setText("------------EMPRESA DE VIAJES-----------\n");
                vista.jTextArea1.append("Direccion: Av. Alfredo Mendiola 6232, Los Olivos 15314 \n");
                vista.jTextArea1.append("Teléfono : +51 908556397 \n");
                vista.jTextArea1.append("Correo Electronico : empresaviaje@gmail.com\n");
                vista.jTextArea1.append("------------TICKET DE PASAJE-----------\n");
                vista.jTextArea1.append("-----DATOS DEL PASAJERO-----\n");
                vista.jTextArea1.append("DNI     :" + c.getDni() + "\n");
                vista.jTextArea1.append("Cliente :" + c.getNombre() + " " + c.getApellido() + "\n");
                vista.jTextArea1.append("-----DETALLES DEL VIAJE-----\n");
                vista.jTextArea1.append("Origen  :" + v.getInicioviaje() + "\n");
                vista.jTextArea1.append("Destino:" + v.getDestinoviaje() + "\n");
                vista.jTextArea1.append("Fecha De Viaje:" + v.getFechaviaje() + "\n");
                vista.jTextArea1.append("Asiento: " + v.getAsiento() + "\n");
                vista.jTextArea1.append("Precio:" + v.getCostopasaje() + "\n");
                vista.jTextArea1.append("Estado De Pago:" + v.getEstadopago() + "\n");
            }
        }
        if (e.getSource() == vista.btnLimpiar) {
            limpiarCampos();
        }
    }

    private void limpiarCampos() {
        vista.jcbxClientesRegistrados.setSelectedItem("SELECCIONA");
        vista.jTextArea1.setText("");
    }

}
