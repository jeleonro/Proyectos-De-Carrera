package Controlador;
import Configuracion.Conexion;
import Servicios.ServicioChofer;
import Dao.DaoChofer;
import Vista.*;
import Modelo.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorChofer extends Conexion implements ActionListener {
    FrmRegistroChofer vista;
    DaoChofer crud;
    Chofer ch;
    public ControladorChofer(FrmRegistroChofer frc) {
        vista = frc;
        vista.setTitle("REGISTRO DE CHOFERES");
        vista.setVisible(true);

        // Asignar listeners a los botones
        vista.btnRegistrar.addActionListener(this);
        vista.btnActualizar.addActionListener(this);
        vista.btneliminar.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnRegistrar) {
                crud = new DaoChofer(vista);
                crud.registrarChofer(ch);// Si el registro es exitoso
                limpiarCampos();
        }
    }


    private void limpiarCampos() {
        vista.txanombrechofer.setText("");
        vista.jtxtapechofer.setText("");
        vista.txanumlic.setText("");
        vista.buttonGroup1.clearSelection();
        vista.jtxtTelefono.setText("");
    }
}
