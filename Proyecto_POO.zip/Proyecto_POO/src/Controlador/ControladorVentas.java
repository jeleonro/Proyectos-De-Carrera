package Controlador;

import Dao.DaoVentasPasajes;
import Vista.*;
import Modelo.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorVentas implements ActionListener {

    FrmVentaPasaje vista;
    VentaDePasaje vp;
    Venta v;
    DaoVentasPasajes crud;
    public ControladorVentas(FrmVentaPasaje fvp) {
        this.vista = fvp;
        this.vp = new VentaDePasaje();
        vista.setTitle("VENTAS DE PASAJE");
        vista.setVisible(true);
        Procesos.ProcesoVentas.Presentar(fvp);
        Procesos.ProcesoVentas.CargarClientes(vista.jcbxClientesRegistrados);
        // Asignar listeners a los ComboBox
        vista.jcbxOrigenruta.addActionListener(this);
        vista.jcbxDestino.addActionListener(this);

        // Listener para botón de registro
        vista.btnRegistroVenta.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.jcbxOrigenruta || e.getSource() == vista.jcbxDestino) {
            // Obtener las selecciones
            String inicio = (String) vista.jcbxOrigenruta.getSelectedItem();
            String destino = (String) vista.jcbxDestino.getSelectedItem();

            // Calcular precio y mostrarlo en el JTextField
            String precio = vp.CalcularPrecioPasaje(inicio, destino);
            vista.jtxtPrecio.setText(precio);
        }

        if (e.getSource() == vista.btnRegistroVenta) {
            crud = new DaoVentasPasajes(vista);
            crud.registrarVentas(v);
        }
    }
}
