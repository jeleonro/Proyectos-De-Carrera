package Controlador;

import Configuracion.Conexion;
import Dao.DaoBuses;
import Servicios.*;
import Modelo.Buses;
import Vista.FrmRegistroBuses;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class ControladorBuses extends Conexion implements ActionListener {

    FrmRegistroBuses vista ;
    DaoBuses crud;
    Buses b;
    
    public ControladorBuses(FrmRegistroBuses frb) {
        vista = frb;
        vista.setTitle("REGISTRO DE BUSES");
        vista.setVisible(true);
        Procesos.ProcesosBuses.Presentar(frb);
        // Asignar listeners a los botones
        vista.btnRegistrarBus.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnRegistrarBus) {
            crud = new DaoBuses(vista);
            if (crud.registrarbuses(b)) { // Si el registro es exitoso
                limpiarCampos();
            }
        }
    }


    private void limpiarCampos() {
        vista.jtxaPlaca.setText("");
        vista.cbxmodelo.setSelectedIndex(0);
        vista.spnCapacidad.setValue(0);
        vista.jtxaañofab.setText("");
        vista.cbxseguro.setSelectedIndex(0);;
    }

}
