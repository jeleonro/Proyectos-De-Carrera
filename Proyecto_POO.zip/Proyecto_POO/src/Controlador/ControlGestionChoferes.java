/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Dao.DaoGestionBuses;
import Dao.DaoGestionChofer;
import Dao.DaoRuta;
import Formatos.Mensajes;
import Modelo.Chofer;
import Vista.FrmGestionarChofer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControlGestionChoferes implements ActionListener{

    DaoGestionChofer crud;
    FrmGestionarChofer vista;
    Chofer c;
    
    public ControlGestionChoferes(FrmGestionarChofer fgc) {
        vista = fgc;
        vista.btnActualizarBus.addActionListener(this);
        vista.btnConsultar.addActionListener(this);
        vista.btnEliminarBus.addActionListener(this);
        vista.setTitle("REGISTRO DE BUSES");
        vista.setVisible(true);
        crud = new DaoGestionChofer(vista);
        crud.actualizarTablaChoferes();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnConsultar) {
            String licencia = Mensajes.M2("Ingrese el num. de licencia del chofer a buscar");
            crud = new DaoGestionChofer(vista);
            c = new Chofer();
            c = crud.ConsultarChofer(licencia);
            if (c == null) {
                Mensajes.M1("La licencia con numero :" + licencia + "no existe en la tabla");
            } else {
                vista.txanombrechofer.setText( c.getNombre());
                vista.jtxtapechofer.setText(  c.getApellido());
                vista.jtxtTelefono.setText(c.getTelefono());
                vista.txanumlic.setText(c.getNumlicencia());
                // Obtener estado de licencia seleccionado
                if("Activo" == c.getEstadolic()){
                    vista.optActivo.setActionCommand("Activo");
                    vista.optActivo.setSelected(true);
                }else{
                     vista.optInactivo.setActionCommand("Inactivo");
                     vista.optInactivo.setSelected(true);
                }
            } // Actualiza la tabla
        }   
        
        if (e.getSource() == vista.btnActualizarBus) {
            crud = new DaoGestionChofer(vista);
            crud.ModificarChofer();
            crud.actualizarTablaChoferes();
        }
        if (e.getSource() == vista.btnEliminarBus) {
            crud = new DaoGestionChofer(vista);
            int fila= vista.tblChoferes.getSelectedRowCount();
            if(fila<1){
                JOptionPane.showMessageDialog(null, "SELECCIONE UN REGISTRO");
            }else{
                if(DaoGestionBuses.eliminarbus(vista.tblChoferes.getValueAt(vista.tblChoferes.getSelectedRow(), 2).toString()));               
                JOptionPane.showMessageDialog(null, "BUS ELIMINADO");
                crud.actualizarTablaChoferes();
            }
        }
    }
}
