package Controlador;

import Dao.DaoMantenimiento;
import Dao.DaoVentasPasajes;
import Vista.*;
import Modelo.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorMantenimiento implements ActionListener {

    FrmMantenimiento vista;
    Buses b;
    DaoMantenimiento crud;
    public ControladorMantenimiento(FrmMantenimiento fm) {
        this.vista = fm;
        crud = new DaoMantenimiento(vista);
        vista.setTitle("MANTENIMIENTO BUSES");
        vista.setVisible(true);
        Procesos.ProcesoMantenimiento.Presentar(fm);
        Procesos.ProcesoMantenimiento.CargarBuses(vista.cbxbus);
        // Asignar listeners a los ComboBox
        crud.actualizarTablaMant();
        // Listener para botón de registro
        vista.btnMantenimiento.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnMantenimiento) {
            crud = new DaoMantenimiento(vista);
            crud.Mantenimiento(b);
            Servicios.ServicioMantenimiento.MostrarMantenimiento(crud.ListaMan(), vista);
        }
    }
}
