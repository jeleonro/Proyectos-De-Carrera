package Controlador;
import Servicios.*;
import Modelo.Usuario;
import Dao.DaoUsuario;
import Vista.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorLogin implements ActionListener{
        login_empresa vista;
        public ControladorLogin(login_empresa le){
            vista=le;
            vista.setTitle("LOGIN");
            vista.setLocationRelativeTo(null);
            vista.setVisible(true);
            vista.btningresar.addActionListener(this);
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == vista.btningresar) {
                autenticarUsuario();
        }   
    }

    public void autenticarUsuario() {
    // Obtener los datos ingresados en la vista
        String username = vista.jtxtusuario.getText();
        String password = new String(vista.jtxtcontraseña.getPassword());
        // Consultar en la base de datos usando el DAO
        Usuario usuario = (new DaoUsuario()).autenticar(username, password);
    
        // Validar el resultado y mostrar un mensaje
        if (usuario != null) {
            JOptionPane.showMessageDialog(vista, "¡Bienvenido, " + usuario.getUsername() + "!");
            FormularioMenu frc= new FormularioMenu();
            ControladorMenu cm = new ControladorMenu(frc);
            frc.setVisible(true);
            vista.dispose();
            // Aquí puedes redirigir al usuario a otra ventana si el login es exitoso
        } else {
            JOptionPane.showMessageDialog(vista, "Usuario o contraseña incorrectos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
