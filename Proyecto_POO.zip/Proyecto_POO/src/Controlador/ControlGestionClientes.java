/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Dao.DaoClientes;
import Dao.DaoGestionBuses;
import Dao.DaoGestionChofer;
import Dao.DaoGestionClientes;
import Formatos.Mensajes;
import Modelo.Cliente;
import Servicios.ServicioClientes;
import Vista.FrmGestionarClientes;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControlGestionClientes implements ActionListener{

    DaoGestionClientes crud;
    FrmGestionarClientes vista;
    Cliente c;
  
    public ControlGestionClientes(FrmGestionarClientes fgc) {
        vista = fgc;
        vista.btnActualizarBus.addActionListener(this);
        vista.btnConsultar.addActionListener(this);
        vista.btnEliminarBus.addActionListener(this);
        vista.setTitle("GESTION DE CLIENTES");
        vista.setVisible(true);
        crud = new DaoGestionClientes(vista);
        crud.actualizarTablaChoferes();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == vista.btnConsultar) {
            String DNI = Mensajes.M2("Ingrese el DNI del cliente a buscar");
            crud = new DaoGestionClientes(vista);
            c = new Cliente();
            c = crud.ConsultarCliente(DNI);
            if (c == null) {
                Mensajes.M1("El cliente con DNI :" + DNI + "no existe en la tabla");
            } else {
                vista.jtxtNombre.setText( c.getNombre());
                vista.jtxtApellido.setText(  c.getApellido());
                vista.jtxtTelefono.setText(c.getTelefono());
                vista.jtxaDni.setText(c.getDni());
                vista.jcbxSexo.setSelectedItem(c.getSexo());
            }
            actualizarTablaCliente();// Actualiza la tabla
        }   
        
        if (e.getSource() == vista.btnActualizarBus) {
            crud = new DaoGestionClientes(vista);
            crud.ModificarCliente();
            actualizarTablaCliente();
            limpiar();
        }
        if (e.getSource() == vista.btnEliminarBus) {
            crud = new DaoGestionClientes(vista);
            int fila= vista.tblDatos.getSelectedRowCount();
            if(fila<1){
                JOptionPane.showMessageDialog(null, "SELECCIONE UN REGISTRO");
            }else{
                if(DaoGestionClientes.eliminarcliente(vista.tblDatos.getValueAt(vista.tblDatos.getSelectedRow(), 2).toString()));               
                JOptionPane.showMessageDialog(null, "CLIENTE ELIMINADO CORRECTAMENTE...");
                actualizarTablaCliente();
            }
        }
    }
    
    
    private void actualizarTablaCliente() {
        crud = new DaoGestionClientes(vista);
        ServicioClientes.MostrarCliente(crud.ListaCliente(), vista);
    }
    
    private void limpiar(){
                vista.jtxtNombre.setText( "");
                vista.jtxtApellido.setText("" );
                vista.jtxtTelefono.setText("");
                vista.jtxaDni.setText("");
                vista.jcbxSexo.setSelectedItem("");
    
    }
    
}

