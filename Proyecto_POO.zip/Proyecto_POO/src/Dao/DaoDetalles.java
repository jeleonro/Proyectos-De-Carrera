package Dao;

import Formatos.*;
import Configuracion.Conexion;
import Modelo.*;
import Vista.*;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class DaoDetalles extends Conexion {
    FrmDetalleVenta vista;

    public DaoDetalles(FrmDetalleVenta vista) {
        this.vista = vista;
    }

    public Venta ConsultarVenta(String cliente) {
        Venta v = null;
        try {
            rs = st.executeQuery("select * from ventapasaje "
                    + "where cliente= '" + cliente + "';");

            if (rs.next()) {
                v = new Venta();
                v.setClienteregistrado(rs.getString("cliente"));
                v.setInicioviaje(rs.getString("inicioruta"));
                v.setDestinoviaje(rs.getString("destinoruta"));
                v.setFechaviaje(rs.getDate("fechaviaje"));
                v.setCostopasaje(rs.getString("precio"));
                v.setEstadopago(rs.getString("estadopago"));
                v.setAsiento(rs.getString("asiento"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return v;
    }
    
    public Cliente ConsultarCliente(String cliente) {
        Cliente c = null;
        try {
            rs = st.executeQuery("select * from clientes_registrados "
                    + "where nombre= '" + cliente + "';");

            if (rs.next()) {
                c = new Cliente();
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellidos"));
                c.setDni(rs.getString("DNI"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return c;
    }
    
    
}
