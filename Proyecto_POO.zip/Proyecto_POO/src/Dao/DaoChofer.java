package Dao;
import Configuracion.Conexion;
import Modelo.Chofer;
import Vista.FrmRegistroChofer;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class DaoChofer extends Conexion {
    FrmRegistroChofer vista;

    public DaoChofer(FrmRegistroChofer vista) {
        this.vista = vista;
    }
    
    public boolean registrarChofer(Chofer ch) {
        String consulta = "INSERT INTO chofer_registrado(nombre, apellidos, num_licencia, estado_licencia, telefono) VALUES(?, ?, ?, ?, ?)";
        try {
            ps = conexion.prepareStatement(consulta);
            // Validar campos obligatorios
            ps.setString(1, vista.txanombrechofer.getText().trim()); // Nombre
            ps.setString(2, vista.jtxtapechofer.getText().trim());   // Apellidos
            ps.setString(3, vista.txanumlic.getText().trim());       // Número de Licencia
            
            // Obtener estado de licencia seleccionado
            vista.optActivo.setActionCommand("Activo");
            vista.optInactivo.setActionCommand("Inactivo");

            String estadoLicencia = vista.buttonGroup1.getSelection().getActionCommand();
            ps.setString(4, estadoLicencia); 
            ps.setString(5, vista.jtxtTelefono.getText().trim());    // Teléfono
            int resultado = ps.executeUpdate();
             if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "Cliente registrado exitosamente.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar el chofer.");
                return false;
            }

       } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar los datos: " + ex.getMessage());
        return false;
       }   
}}

