package Dao;

import Configuracion.Conexion;
import Modelo.*;
import Vista.FrmVentaPasaje;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DaoVentasPasajes extends Conexion {

    FrmVentaPasaje vista;

    public DaoVentasPasajes(FrmVentaPasaje vista) {
        this.vista = vista;
    }

    public boolean registrarVentas(Venta v) {
        String consulta = "INSERT INTO ventapasaje (cliente, inicioruta, destinoruta, fechaviaje, precio,estadopago,asiento) VALUES (?, ?, ?, ?, ?,?,?)";

        try {
            ps = conexion.prepareStatement(consulta);
            // Validar campos obligatorios
            if (vista.jcbxClientesRegistrados.getSelectedItem().toString().isEmpty()
                    || vista.jcbxOrigenruta.getSelectedItem().toString().isEmpty()
                    || vista.jcbxEstadoPasaje.getSelectedItem().toString().isEmpty()
                    || vista.jtxtPrecio.getText().isEmpty()
                    || vista.jcbxDestino.getSelectedItem().toString() == null) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
                return false;
            }

            ps.setString(1, vista.jcbxClientesRegistrados.getSelectedItem().toString().trim()); // Nombre
            ps.setString(2, vista.jcbxOrigenruta.getSelectedItem().toString().trim());   // Apellidos
            ps.setString(3, vista.jcbxDestino.getSelectedItem().toString().trim());       // Número de Licencia     
            if (vista.jcbxFechaProgramada.getDate() != null) {
                Date fecha = vista.jcbxFechaProgramada.getDate();
                java.sql.Date sqlDate = new java.sql.Date(fecha.getTime()); // Convertir a java.sql.Date
                ps.setDate(4, sqlDate);
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, selecciona una fecha válida.");
                return false;
            }
            ps.setString(5, vista.jtxtPrecio.getText().trim());// Teléfono
            ps.setString(6, vista.jcbxEstadoPasaje.getSelectedItem().toString().trim());
            ps.setInt(7, Integer.parseInt(vista.spnAsiento.getValue().toString()));
            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "Venta registrada exitosamente.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar la venta....");
                return false;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar los datos: " + ex.getMessage());
            return false;
        }
    }

}

