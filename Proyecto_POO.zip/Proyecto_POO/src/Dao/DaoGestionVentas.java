package Dao;
import Configuracion.*;
import Formatos.Mensajes;
import Modelo.*;
import Servicios.*;
import Vista.FrmGestionarVentas;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class DaoGestionVentas extends Conexion {

    FrmGestionarVentas vista;
    DaoGestionVentas crud;
    public DaoGestionVentas(FrmGestionarVentas vista) {
        this.vista = vista;
    }

    public List<Venta> ListaVentas() {
        List<Venta> lista = new ArrayList<>();
        String consulta = "SELECT cliente, inicioruta, destinoruta, fechaviaje, precio,estadopago, asiento FROM ventapasaje ORDER BY cliente";

        try {
            rs = st.executeQuery(consulta);

            while (rs.next()) {
                Venta v = new Venta();
                v.setClienteregistrado(rs.getString("cliente"));
                v.setInicioviaje(rs.getString("inicioruta"));
                v.setDestinoviaje(rs.getString("destinoruta"));
                v.setFechaviaje(rs.getDate("fechaviaje"));
                v.setCostopasaje(rs.getString("precio"));
                v.setEstadopago(rs.getString("estadopago"));
                v.setAsiento(rs.getString("asiento"));
                lista.add(v);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + e.getMessage());
        }
        return lista;
    }
    
    public List<Venta> filtrarPorFecha(Date fecha) {
    List<Venta> lista = new ArrayList<>();
    String consulta = "SELECT cliente, inicioruta,destinoruta,fechaviaje,precio,estadopago, asiento FROM ventapasaje WHERE fechaviaje = ? ORDER BY fechaviaje";

    try {
        ps = conexion.prepareStatement(consulta);
        ps.setDate(1, new java.sql.Date(fecha.getTime())); // Convertir la fecha de java.util.Date a java.sql.Date
        rs = ps.executeQuery();

        while (rs.next()) {
            Venta v = new Venta();
                v.setClienteregistrado(rs.getString("cliente"));
                v.setInicioviaje(rs.getString("inicioruta"));
                v.setDestinoviaje(rs.getString("destinoruta"));
                v.setFechaviaje(rs.getDate("fechaviaje"));
                v.setCostopasaje(rs.getString("precio"));
                v.setEstadopago(rs.getString("estadopago"));
                v.setAsiento(rs.getString("asiento"));
                lista.add(v);
        }
    } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Error al recuperar los datos filtrados: " + e.getMessage());
    }
    return lista;
}
    
    public static boolean eliminarventa(String cliente) {
        String consulta = "delete from ventaspasajes where cliente ='" + cliente + "';";
        try (Connection cn = new Conexion().conexion; PreparedStatement ps = cn.prepareStatement(consulta)) {
            ps.execute();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return true;
    }
    
        public void actualizarTablaVentas() {
        crud = new DaoGestionVentas(vista);
        ServicioVentasPasajes.MostrarVentas(crud.ListaVentas(), vista);
    }
}

