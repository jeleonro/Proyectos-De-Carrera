/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Modelo.Buses;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import Configuracion.Conexion;
import Formatos.Mensajes;
import Vista.FrmGestionarBuses;
import Vista.FrmRegistroBuses;
import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class DaoGestionBuses extends Conexion {

    FrmGestionarBuses vista;
    public DaoGestionBuses(FrmGestionarBuses vista) {
        this.vista = vista;
    }

    public List<Buses> ListaBuses() {
        List<Buses> listabus = new ArrayList<>();
        String consultabus = "SELECT modelo,placa, capacidad, añofabricacion, seguro FROM buses_registrados ORDER BY modelo";
        try {
            rs = st.executeQuery(consultabus);
            while (rs.next()) {
                Buses bs = new Buses();
                bs.setModelo(rs.getString("modelo"));
                bs.setPlaca(rs.getString("placa"));
                bs.setCapacidad(rs.getInt("capacidad"));
                bs.setAñofabricacion(rs.getString("añofabricacion"));
                bs.setSeguro(rs.getString("seguro"));
                listabus.add(bs);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos" + e.getMessage());
        }
        return listabus;
    }

    public Buses ConsultarBus(String placa) {
        Buses bus = null;
        try {
            rs = st.executeQuery("select * from buses_registrados "
                    + "where placa= '" + placa + "';");
            if (rs.next()) {
                // Crear el objeto Buses con los datos obtenidos
                bus = new Buses();
                bus.setModelo(rs.getString("modelo"));
                bus.setPlaca(rs.getString("placa"));
                bus.setCapacidad(rs.getInt("capacidad"));
                bus.setAñofabricacion(rs.getString("añofabricacion"));
                bus.setSeguro(rs.getString("seguro"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
    }
        return bus;
    }
    public static boolean eliminarbus(String placa){
        String consulta = "delete from buses_registrados where placa ='"+ placa+"';" ;
        try(Connection cn = new Conexion().conexion;
            PreparedStatement ps = cn.prepareStatement(consulta)) {
            ps.execute();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
    }
        return true;  
    }
}