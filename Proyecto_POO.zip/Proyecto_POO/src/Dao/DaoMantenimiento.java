
package Dao;
import Configuracion.Conexion;
import Modelo.Buses;
import Modelo.Mantenimiento;
import Servicios.ServicioMantenimiento;
import Vista.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
public class DaoMantenimiento extends Conexion {
    FrmMantenimiento vista;
    DaoMantenimiento crud;
    public DaoMantenimiento(FrmMantenimiento vista) {
        this.vista = vista;
    }

    public List<Mantenimiento> ListaMan() {
        List<Mantenimiento> lista = new ArrayList<>();
        String consulta = "SELECT bus,detalle,fecha_mantenimiento FROM mantenimiento_bus ORDER BY fecha_mantenimiento";
        try {
            ps = conexion.prepareStatement(consulta);
            rs = ps.executeQuery();
            while (rs.next()) {
                Mantenimiento m = new Mantenimiento();
                m.setBus(rs.getString("bus"));
                m.setDetalle(rs.getString("detalle"));
                m.setFechamantenimiento(rs.getDate("fecha_mantenimiento"));
                lista.add(m);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + e.getMessage());
        }
        return lista;
    }
    
    
    public boolean Mantenimiento(Buses b) {
        String consultabus = "INSERT INTO mantenimiento_bus (bus,detalle,fecha_mantenimiento) VALUES (?, ?, ?)";

        try {ps = conexion.prepareStatement(consultabus);
            
            ps.setString(1, vista.cbxbus.getSelectedItem().toString()); // Modelo
            ps.setString(2, vista.cbxMotivo.getSelectedItem().toString().trim());
            if (vista.jDateChooser1.getDate() != null) {
                Date fecha = vista.jDateChooser1.getDate();
                java.sql.Date sqlDate = new java.sql.Date(fecha.getTime()); // Convertir a java.sql.Date
                ps.setDate(3, sqlDate);
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, selecciona una fecha válida.");
                return false;
            }
            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "Bus registrado exitosamente....");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar el bus...");
                return false;
            }

        } catch (Exception ex) {
            System.out.println("error");
            return false;
        }
    }
            public void actualizarTablaMant() {
        crud = new DaoMantenimiento(vista);
        ServicioMantenimiento.MostrarMantenimiento(crud.ListaMan(), vista);
    }
}

