package Dao;
import Configuracion.*;
import Formatos.Mensajes;
import Modelo.Cliente;
import Servicios.*;
import Vista.FrmGestionarClientes;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class DaoGestionClientes extends Conexion {

    FrmGestionarClientes vista;
    DaoGestionClientes crud;
    public DaoGestionClientes(FrmGestionarClientes vista) {
        this.vista = vista;
    }

    public List<Cliente> ListaCliente() {
        List<Cliente> lista = new ArrayList<>();
        String consulta = "SELECT nombre, apellidos, DNI, sexo, telefono FROM clientes_registrados ORDER BY apellidos";

        try {
            rs = st.executeQuery(consulta);

            while (rs.next()) {
                Cliente cl = new Cliente();
                cl.setNombre(rs.getString("nombre"));
                cl.setApellido(rs.getString("apellidos"));
                cl.setDni(rs.getString("DNI"));
                cl.setSexo(rs.getString("sexo"));
                cl.setTelefono(rs.getString("telefono"));
                lista.add(cl);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + e.getMessage());
        }
        return lista;
    }

    public Cliente ConsultarCliente(String dni) {
        Cliente c = null;
        try {
            rs = st.executeQuery("select * from clientes_registrados "
                    + "where DNI= '" + dni + "';");

            if (rs.next()) {
                c = new Cliente();
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellidos"));
                c.setDni(rs.getString("DNI"));
                c.setSexo(rs.getString("sexo"));
                c.setTelefono(rs.getString("telefono"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return c;
    }

    public void ModificarCliente() {
        String consultachofer = "update clientes_registrados set nombre=?, apellidos=?, sexo=?,telefono=? where DNI=?";
        try {
            ps = conexion.prepareStatement(consultachofer);
            ps.setString(1, vista.jtxtNombre.getText().trim());
            ps.setString(2, vista.jtxtApellido.getText().trim());
            ps.setString(3,vista.jcbxSexo.getSelectedItem().toString());
            ps.setString(4, vista.jtxtTelefono.getText());
            ps.setString(5, vista.jtxaDni.getText());
            int a = ps.executeUpdate();
            if (a > 0) {
                    JOptionPane.showMessageDialog(null, "Datos del cliente modificado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "Error al agregar.");
                }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos" + e.getMessage());
        }
    }
    
    public static boolean eliminarcliente(String DNI) {
        String consulta = "delete from clientes_registrados where DNI ='" + DNI + "';";
        try (Connection cn = new Conexion().conexion; PreparedStatement ps = cn.prepareStatement(consulta)) {
            ps.execute();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return true;
    }
    
        public void actualizarTablaChoferes() {
        crud = new DaoGestionClientes(vista);
        ServicioClientes.MostrarCliente(crud.ListaCliente(), vista);
    }
}
