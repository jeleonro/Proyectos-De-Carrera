package Dao;

import Formatos.*;
import Configuracion.Conexion;
import Modelo.*;
import Vista.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;

public class DaoRuta extends Conexion {
    FrmRutasViaje vista;
    Date utildate = new Date();

    public DaoRuta(FrmRutasViaje vista) {
        this.vista = vista;
    }
    
    public List<Rutas> ListaRuta() {
        List<Rutas> lista = new ArrayList<>();
        String consulta = "SELECT InicioRuta, DestinoRuta, Fecha, Hora, BusAsignado, ChoferAsignado FROM rutas_de_viaje ORDER BY Fecha";

        try {
            rs = st.executeQuery(consulta);

            while (rs.next()) {
                Rutas r = new Rutas();
                r.setInicioruta(rs.getString("InicioRuta"));
                r.setDestinoruta(rs.getString("DestinoRuta"));
                r.setFecha(rs.getDate("Fecha"));
                r.setHora(rs.getTime("Hora"));
                r.setBusasignado(rs.getString("BusAsignado"));
                r.setChoferasignado(rs.getString("ChoferAsignado"));
                lista.add(r);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + e.getMessage());
        }
        return lista;
    }

    public boolean ProgramarRuta(Rutas r) {
        String consulta = "INSERT INTO rutas_de_viaje(InicioRuta, DestinoRuta, Fecha, Hora, BusAsignado, ChoferAsignado) VALUES (?, ?, ?, ?, ?,?)";

        try {
            ps = conexion.prepareStatement(consulta);

            ps.setString(1, vista.jcbxOrigenruta.getSelectedItem().toString().trim()); // InicioRuta
            ps.setString(2, vista.jcbxDestino.getSelectedItem().toString().trim());
            // Validar fecha
            if (vista.jdtf_fecha.getDate() != null) {
                Date fecha = vista.jdtf_fecha.getDate();
                java.sql.Date sqlDate = new java.sql.Date(fecha.getTime()); // Convertir a java.sql.Date
                ps.setDate(3, sqlDate);
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, selecciona una fecha válida.");
                return false;
            }

            // Validar hora
            if (vista.jdtf_hora.getDate() != null) {
                utildate = vista.jdtf_hora.getDate();
                Time sqlTime = new Time(utildate.getTime());
                ps.setTime(4, sqlTime);
            } else {
                JOptionPane.showMessageDialog(null, "Por favor, selecciona una hora válida.");
                return false;
            }
            ps.setString(5, vista.jtxtBus.getText().trim());
            ps.setString(6, vista.jtxtChofer.getText().trim());

            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "Ruta programada exitosamente.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar el chofer.");
                return false;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar los datos: " + ex.getMessage());
            return false;
        }
    }


    public Chofer ConsultarChofer(String licencia) {
        Chofer c = null;
        try {
            rs = st.executeQuery("select * from chofer_registrado "
                    + "where num_licencia= '" + licencia + "';");

            if (rs.next()) {
                c = new Chofer();
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellidos"));
                c.setNumlicencia(rs.getString("num_licencia"));
                c.setEstadolic(rs.getString("estado_licencia"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return c;
    }
    
    public Buses ConsultarBus(String placabus) {
        Buses b = null;
        try {
            rs = st.executeQuery("select * from buses_registrados "
                    + "where placa= '" + placabus + "';");

            if (rs.next()) {
                b = new Buses();
                b.setPlaca(rs.getString("placa"));
                b.setModelo(rs.getString("modelo"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return b;
    }
    
    public static boolean eliminarruta(Date fecha) {
        String consulta = "delete from rutas_de_viaje where fecha ='" + fecha + "';";
        try (Connection cn = new Conexion().conexion; PreparedStatement ps = cn.prepareStatement(consulta)) {
            ps.execute();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return true;
    }
}
