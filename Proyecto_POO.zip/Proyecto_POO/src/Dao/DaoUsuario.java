
package Dao;
import Configuracion.Conexion;
import java.sql.SQLException;
import Modelo.Usuario;
public class DaoUsuario extends Conexion {
    public Usuario autenticar(String username, String password) {
        Usuario usuario = null;
        try {
            String consultausuario = "SELECT * FROM usuarios_login WHERE username = ? AND password = ?";
            ps = conexion.prepareStatement(consultausuario);
            ps.setString(1, username);
            ps.setString(2, password);
            rs = ps.executeQuery();
            if (rs.next()) {
                usuario = new Usuario(rs.getString("username"), rs.getString("password"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return usuario;
    }
    
    
}
