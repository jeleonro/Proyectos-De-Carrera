
package Dao;
import Configuracion.Conexion;
import Modelo.Buses;
import Vista.FrmRegistroBuses;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
public class DaoBuses extends Conexion {
    FrmRegistroBuses vista;

    public DaoBuses(FrmRegistroBuses vista) {
        this.vista = vista;
    }

    public boolean registrarbuses(Buses b) {
        String consultabus = "INSERT INTO buses_registrados (modelo, placa, capacidad, añofabricacion, seguro) VALUES (?, ?, ?, ?, ?)";

        try {ps = conexion.prepareStatement(consultabus);

            // Validar campos obligatorios
            if (vista.jtxaPlaca.getText().isEmpty()
                    || vista.cbxmodelo.getSelectedItem().toString().isEmpty()
                    || vista.spnCapacidad.getValue() == null) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
                return false;
            }
            
            ps.setString(1, vista.cbxmodelo.getSelectedItem().toString()); // Modelo
            ps.setString(2, vista.jtxaPlaca.getText().trim());
            ps.setString(3, vista.spnCapacidad.getValue().toString());   // Capacidad
            ps.setString(4, vista.jtxaañofab.getText().trim());
            ps.setString(5, vista.cbxseguro.getSelectedItem().toString());
            
            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "Bus registrado exitosamente....");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar el bus...");
                return false;
            }

        } catch (Exception ex) {
            return false;
        }
    }
}
