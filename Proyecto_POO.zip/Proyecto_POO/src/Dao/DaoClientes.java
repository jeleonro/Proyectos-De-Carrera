package Dao;

import Configuracion.Conexion;
import Modelo.*;
import Vista.FrmRegistroCliente;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class DaoClientes extends Conexion {

    FrmRegistroCliente vista;

    public DaoClientes(FrmRegistroCliente vista) {
        this.vista = vista;
    }

    public List<Cliente> ListaCliente() {
        List<Cliente> lista = new ArrayList<>();
        String consulta = "SELECT nombre, apellidos, DNI, sexo, telefono FROM clientes_registrados ORDER BY apellidos";

        try {
            rs = st.executeQuery(consulta);

            while (rs.next()) {
                Cliente cl = new Cliente();
                cl.setNombre(rs.getString("nombre"));
                cl.setApellido(rs.getString("apellidos"));
                cl.setDni(rs.getString("DNI"));
                cl.setSexo(rs.getString("sexo"));
                cl.setTelefono(rs.getString("telefono"));
                lista.add(cl);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + e.getMessage());
        }
        return lista;
    }

    public boolean registrarCliente(Cliente cl) {
        String consulta = "INSERT INTO clientes_registrados (nombre, apellidos, DNI, sexo, telefono) VALUES (?, ?, ?, ?, ?)";

        try {
            ps = conexion.prepareStatement(consulta);
            // Validar campos obligatorios
            if (vista.jtxtNombre.getText().isEmpty()
                    || vista.jtxtApellido.getText().isEmpty()
                    || vista.jtxaDni.getText().isEmpty()
                    || vista.jcbxSexo.getSelectedItem().toString().isEmpty()
                    || vista.jtxtTelefono.getText() == null) {
                JOptionPane.showMessageDialog(null, "Por favor, complete todos los campos.");
                return false;
            }

            ps.setString(1, vista.jtxtNombre.getText().trim()); // Nombre
            ps.setString(2, vista.jtxtApellido.getText().trim());   // Apellidos
            ps.setString(3, vista.jtxaDni.getText().trim());       // Número de Licencia     
            ps.setString(4, vista.jcbxSexo.getSelectedItem().toString().trim());
            ps.setString(5, vista.jtxtTelefono.getText().trim());    // Teléfono

            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                JOptionPane.showMessageDialog(null, "Cliente registrado exitosamente.");
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Error al registrar el chofer.");
                return false;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar los datos: " + ex.getMessage());
            return false;
        }
    }

    public static void eliminarFilaSeleccionada(JTable tabla) {
        // Obtiene el modelo de la tabla
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();

        // Verifica si hay una fila seleccionada
        int filaSeleccionada = tabla.getSelectedRow();
        if (filaSeleccionada >= 0) {
            // Elimina la fila seleccionada del modelo
            modelo.removeRow(filaSeleccionada);
            JOptionPane.showMessageDialog(null, "Fila eliminada correctamente.");
        } else {
            // Mensaje de error si no se seleccionó ninguna fila
            JOptionPane.showMessageDialog(null, "Por favor, selecciona una fila para eliminar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

}
