/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import Modelo.Chofer;
import Configuracion.*;
import Formatos.Mensajes;
import Servicios.ServicioChofer;
import Vista.FrmGestionarBuses;
import Vista.FrmGestionarChofer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author USER
 */
public class DaoGestionChofer extends Conexion {

    FrmGestionarChofer vista;
    DaoGestionChofer crud;
    public DaoGestionChofer(FrmGestionarChofer vista) {
        this.vista = vista;
    }

    public List<Chofer> ListaChofer() {
        List<Chofer> lista = new ArrayList<>();
        String consulta = "SELECT nombre, apellidos, num_licencia, estado_licencia, telefono FROM chofer_registrado ORDER BY apellidos";
        try {
            ps = conexion.prepareStatement(consulta);
            rs = ps.executeQuery();
            while (rs.next()) {
                Chofer cr = new Chofer();
                cr.setNombre(rs.getString("nombre"));
                cr.setApellido(rs.getString("apellidos"));
                cr.setNumlicencia(rs.getString("num_licencia"));
                cr.setEstadolic(rs.getString("estado_licencia"));
                cr.setTelefono(rs.getString("telefono"));
                lista.add(cr);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al recuperar los datos: " + e.getMessage());
        }
        return lista;
    }

    public Chofer ConsultarChofer(String licencia) {
        Chofer c = null;
        try {
            rs = st.executeQuery("select * from chofer_registrado "
                    + "where num_licencia= '" + licencia + "';");

            if (rs.next()) {
                c = new Chofer();
                c.setNombre(rs.getString("nombre"));
                c.setApellido(rs.getString("apellidos"));
                c.setNumlicencia(rs.getString("num_licencia"));
                c.setEstadolic(rs.getString("estado_licencia"));
                c.setTelefono(rs.getString("telefono"));
            }
            rs.close();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return c;
    }

    public void ModificarChofer() {
        String consultachofer = "update chofer_registrado set nombre=?, apellidos=?, estado_licencia=?, telefono=? where num_licencia=?";
        try {
            ps = conexion.prepareStatement(consultachofer);
            ps.setString(1, vista.txanombrechofer.getText().trim());
            ps.setString(2, vista.jtxtapechofer.getText().trim());
       
            // Obtener estado de licencia seleccionado
            vista.optActivo.setActionCommand("Activo");
            vista.optInactivo.setActionCommand("Inactivo");
            ps.setString(3, vista.buttonGroup1.getSelection().getActionCommand());
            
            ps.setString(4, vista.jtxtTelefono.getText());
            ps.setString(5, vista.txanumlic.getText());
            int a = ps.executeUpdate();
            if (a > 0) {
                    JOptionPane.showMessageDialog(null, "Datos del chofer modificado exitosamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "Error al agregar.");
                }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al cargar los datos" + e.getMessage());
        }
    }
    
    public static boolean eliminarchofer(String licencia) {
        String consulta = "delete from chofer_registrado where num_licencia ='" + licencia + "';";
        try (Connection cn = new Conexion().conexion; PreparedStatement ps = cn.prepareStatement(consulta)) {
            ps.execute();
        } catch (Exception ex) {
            Mensajes.M1("ERROR NO SE PUEDE CONSULTAR" + ex);
        }
        return true;
    }
    
        public void actualizarTablaChoferes() {
        crud = new DaoGestionChofer(vista);
        ServicioChofer.MostrarChofer(crud.ListaChofer(), vista);
    }
}
