package Principal;

import Controlador.*;
import Vista.*;

public class Main {

    public static login_empresa le;

    public static ControladorLogin contrologin;

    public static FrmRegistroChofer frc;

    public static ControladorChofer controlchofer;
    
    public static FrmGestionarChofer fgc;
    
    public static ControlGestionChoferes cgc;

    public static FrmRegistroBuses frb;

    public static ControladorBuses controlbus;
    
    public static FrmGestionarBuses fgb;
    
    public static ControlGestionBuses cgb;
    
    public static FrmMantenimiento fm;
    
    public static ControladorMantenimiento cm;

    public static FrmRegistroCliente fc;

    public static ControladorCliente controlcliente;
    
    public static FrmGestionarClientes fgcli;
    
    public static ControlGestionClientes cgcli;

    public static FrmRutasViaje frv;

    public static ControladorRutas controlrutas;

    public static FrmVentaPasaje fvp;
    
    public static ControladorVentas cv;
    
    public static FrmGestionarVentas fgv;
    
    public static ControlGestionVentas cgv;
    
    public static FrmDetalleVenta fdv;
    
    public static ControlDetalleVenta cdv;
    
    public static void main(String[] args) {
        le = new login_empresa();
        contrologin = new ControladorLogin(le);
    }
}
