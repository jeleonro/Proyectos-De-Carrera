package Configuracion;

import java.sql.*;
import javax.swing.JOptionPane;

public class Conexion extends Parametros {

    public Connection conexion;

    public Statement st;

    public ResultSet rs;

    public PreparedStatement ps;

    public ResultSetMetaData mdata;

    public Conexion() {
        try {
            Class.forName(DRIVER);
            conexion = DriverManager.getConnection(URL, USUARIO, CLAVE);
            st = conexion.createStatement();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al conectar la base de datos..");
        }
    }
}
