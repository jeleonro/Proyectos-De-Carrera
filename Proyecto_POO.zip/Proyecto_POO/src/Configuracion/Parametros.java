package Configuracion;

public class Parametros {

    String DRIVER = "com.mysql.cj.jdbc.Driver";

    String URL = "jdbc:mysql://localhost:3306/empresa_viaje";

    String USUARIO = "root";

    String CLAVE = "250306";
}
