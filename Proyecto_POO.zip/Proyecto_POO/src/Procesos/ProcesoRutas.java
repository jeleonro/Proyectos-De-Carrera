package Procesos;

import Datos.*;
import Configuracion.Conexion;
import Vista.*;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class ProcesoRutas extends Conexion {
    public static void Presentar(FrmRutasViaje frv) {
        frv.jcbxDestino.removeAllItems();
        for (String dest : Constantes.destino) { 
            frv.jcbxDestino.addItem(dest);
        }
        frv.jcbxOrigenruta.removeAllItems();
        for (String or : Constantes.origen) { 
            frv.jcbxOrigenruta.addItem(or);
        }
        
        frv.setVisible(true); 
}
        
    }



