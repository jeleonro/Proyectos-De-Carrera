package Procesos;
import Configuracion.Conexion;
import Datos.*;
import Vista.*;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
public class ProcesoCliente extends Conexion{
    public static void Presentar(FrmRegistroCliente frc) {
        frc.jcbxSexo.removeAllItems();
        for (String sexo : Constantes.sexo) { 
            frc.jcbxSexo.addItem(sexo);
        }
        frc.setVisible(true);
    }  
    
    // PARA LA VENTA DE PASAJES....
    public void ClientesRegistrados(JComboBox<String> combobox,FrmVentaPasaje fvp){
        String consulta = "SELECT nombre, apellidos FROM clientes_registrados";
        try{
            ps = conexion.prepareStatement(consulta);
            rs = ps.executeQuery();
            
           fvp.jcbxClientesRegistrados.removeAllItems();
           fvp.jcbxClientesRegistrados.addItem("Seleccione un cliente");
           
           while(rs.next()){
               String nombre = rs.getString("nombre")+" "+rs.getString("apellidos");
               fvp.jcbxClientesRegistrados.addItem(nombre);
           }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar los datos: " + ex.getMessage());
        }
        
    }
    }
