/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Procesos;

import Configuracion.Conexion;
import Datos.Constantes;
import Vista.FrmRegistroBuses;
import Vista.FrmRegistroCliente;
public class ProcesosBuses extends Conexion {
    public static void Presentar(FrmRegistroBuses frb) {
        frb.cbxseguro.removeAllItems();
        frb.cbxmodelo.removeAllItems();
        for (String seguro : Constantes.segurobus) { 
            frb.cbxseguro.addItem(seguro);
        }
        for (String modelo : Constantes.modelobus) { 
            frb.cbxmodelo.addItem(modelo);
        }
        frb.setVisible(true);
    }
}
