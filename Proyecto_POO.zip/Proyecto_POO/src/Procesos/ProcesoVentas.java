package Procesos;

import Configuracion.*;
import Datos.Constantes;
import Vista.FrmVentaPasaje;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class ProcesoVentas extends Conexion{
    public static void Presentar(FrmVentaPasaje frp) {
        frp.jcbxDestino.removeAllItems();
        for (String dest : Constantes.destino) { 
            frp.jcbxDestino.addItem(dest);
        }
        frp.jcbxOrigenruta.removeAllItems();
        for (String or : Constantes.origen) { 
            frp.jcbxOrigenruta.addItem(or);
        }
        frp.jcbxEstadoPasaje.removeAllItems();
        for(String ep:Constantes.estadopasaje){
            frp.jcbxEstadoPasaje.addItem(ep);
        }
       
        frp.setVisible(true);     
}
    public static void CargarClientes(JComboBox<String> cbx){
        String consulta = "select nombre from clientes_registrados";
        try(Connection cn = new Conexion().conexion) {
            Statement st = (Statement) cn.createStatement();
            ResultSet rs = st.executeQuery(consulta); 
            cbx.removeAllItems();
           
            while (rs.next()) {                
                cbx.addItem(rs.getString("nombre"));
            }
           
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al conectar"
                    + " a la base de datos: " + e.getMessage());
        }
    }
    
    
}
