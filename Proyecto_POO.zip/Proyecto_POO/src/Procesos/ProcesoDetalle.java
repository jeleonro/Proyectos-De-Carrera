package Procesos;

import Configuracion.Conexion;
import Vista.FrmVentaPasaje;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

public class ProcesoDetalle extends Conexion{
    public void ClientesRegistrados(JComboBox<String> combobox,FrmVentaPasaje fvp){
        String consulta = "SELECT nombre, apellidos FROM clientes_registrados";
        try{
            ps = conexion.prepareStatement(consulta);
            rs = ps.executeQuery();
            
           fvp.jcbxClientesRegistrados.removeAllItems();
           fvp.jcbxClientesRegistrados.addItem("Seleccione un cliente");
           
           while(rs.next()){
               String nombre = rs.getString("nombre")+" "+rs.getString("apellidos");
               fvp.jcbxClientesRegistrados.addItem(nombre);
           }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error al procesar los datos: " + ex.getMessage());
        }
        
    }
}
