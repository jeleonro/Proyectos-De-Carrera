/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;

import Modelo.Mantenimiento;
import Modelo.Rutas;
import Vista.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author USER
 */
public class ServicioMantenimiento {
    public static void MostrarMantenimiento(List<Mantenimiento> listaMantenimiento, FrmMantenimiento fm) {
        String[] titulos = {"BUS", "DETALLE", "FECHA"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        fm.tblChoferes.setModel(modelo);
        /*Recorre la lista de objetos Rutas y por cada objeto
        luego se crea una fila y se agrega al modelo de la tabla, para que
        la tabla muestre una fila por cada elemento en listarutas*/
        for (Mantenimiento m : listaMantenimiento) {
            Object[] fila = {
                m.getBus(),
                m.getDetalle(),
                m.getFechamantenimiento()
            };
            modelo.addRow(fila);
        }
    }
}
