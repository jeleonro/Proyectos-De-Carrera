package Servicios;
import Modelo.*;
import Vista.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ServicioVentasPasajes {
    public static void MostrarVentas(List<Venta> lista, FrmGestionarVentas fvp) {
        String[] titulos = {"CLIENTE","ORIGEN", "DESTINO", "FECHA", "PRECIO","ASIENTO","ESTADO"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        fvp.jtblPasajes.setModel(modelo);
        for(int i= 0; i<lista.size();i++){
            modelo.addRow(lista.get(i).RegistroVentas());
        }
    }
}
