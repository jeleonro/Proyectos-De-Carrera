
package Servicios;

import Modelo.*;
import Vista.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ServicioClientes {
    public static void MostrarCliente(List<Cliente> lista, FrmGestionarClientes fgcli) {
        String[] titulos = {"NOMBRE", "APELLIDO", "Nº DE DNI", "SEXO", "TELÉFONO"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        fgcli.tblDatos.setModel(modelo);

        for (Cliente cliente : lista) {
            Object[] fila = {
                cliente.getNombre(),
                cliente.getApellido(),
                cliente.getDni(),
                cliente.getSexo(),
                cliente.getTelefono()
            };
            modelo.addRow(fila);
        }
    }
}
