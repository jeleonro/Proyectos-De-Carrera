package Servicios;
import Modelo.Chofer;
import java.util.List;
import Vista.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class ServicioChofer {
    public static void MostrarChofer(List<Chofer> lista, FrmGestionarChofer fgc) {
        String[] titulos = {"NOMBRE", "APELLIDO", "Nº DE LICENCIA", "ESTADO LIC.", "TELÉFONO"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        fgc.tblChoferes.setModel(modelo);

        for (Chofer chofer : lista) {
            Object[] fila = {
                chofer.getNombre(),
                chofer.getApellido(),
                chofer.getNumlicencia(),
                chofer.getEstadolic(),
                chofer.getTelefono()
            };
            modelo.addRow(fila);
        }
    }
}

