/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicios;
import Modelo.*;
import Vista.*;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class ServicioRuta {
    public static void MostrarRutas(List<Rutas> listarutas, FrmRutasViaje frv) {
        String[] titulos = {"ORIGEN", "DESTINO", "FECHA", "HORA", "BUS ASIGNADO","CHOFER ASIGNADO"};
        DefaultTableModel modelo = new DefaultTableModel(null, titulos);
        frv.tblRutas.setModel(modelo);
        /*Recorre la lista de objetos Rutas y por cada objeto
        luego se crea una fila y se agrega al modelo de la tabla, para que
        la tabla muestre una fila por cada elemento en listarutas*/
        for (Rutas ruta : listarutas) {
            Object[] fila = {
                ruta.getInicioruta(),
                ruta.getDestinoruta(),
                ruta.getFecha(),
                ruta.getHora(),
                ruta.getBusasignado(),
                ruta.getChoferasignado()
            };
            modelo.addRow(fila);
        }
    }
}
