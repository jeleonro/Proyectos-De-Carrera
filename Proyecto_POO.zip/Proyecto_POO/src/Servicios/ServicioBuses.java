package Servicios;
import Vista.*;
import Modelo.Buses;
import java.util.List;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class ServicioBuses {
    public static void MostrarBuses(List<Buses> listabus, FrmGestionarBuses fgb ){
        String[] titulosbus = {"MODELO", "PLACA", "CAPACIDAD", "AÑO FABRICACION", "SEGURO"};
        DefaultTableModel modelobus = new DefaultTableModel(null,titulosbus);
        fgb.tblBuses.setModel(modelobus);
        // Para actualizar la lista de buses   
        for(Buses bus : listabus){
            Object[] filabus = { 
                bus.getModelo(),
                bus.getPlaca(),
                bus.getCapacidad(),
                bus.getAñofabricacion(),
                bus.getSeguro()
            };
            modelobus.addRow(filabus);
            }
        }
        
    }
